export const host = "https://api.whitefoxtravels.com/";
// export const host = "http://192.168.1.54:9000/";
export const siteid = "02";
